angular
    .module('TaskOneApp')
    .controller('GetKeywordController', function($rootScope, $scope) {

    });
