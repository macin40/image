var app = angular.module('TaskOneApp', [
    'ngRoute'
]);